# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, HttpResponse, redirect

# Create your views here.
def index(request):
    return HttpResponse('placholder to later display all blog posts')

def new(request):
    return HttpResponse('placeholder to display a new form to create a new blog')

def create(reqest):
    return redirect('/')

def show(request, number):
    return HttpResponse('placeholder to display blog ' + number)

def edit(request, number):
    return HttpResponse('placeholder to edit blog ' + number)

def destroy(request, number):
    return redirect('/')