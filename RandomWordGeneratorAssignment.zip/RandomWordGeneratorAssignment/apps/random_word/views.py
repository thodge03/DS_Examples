# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, HttpResponse, redirect
from django.utils.crypto import get_random_string

# Create your views here.

def index(request):
    request.session['attempt'] = 0
    return render(request, 'random_word/index.html')

def generate(request):
    request.session['word'] = get_random_string(length=14)
    request.session['attempt'] += 1
    return render(request, 'random_word/index.html')

def reset(request):
    for key in request.session.keys():
        del request.session[key]
    return redirect('/random_word')
            