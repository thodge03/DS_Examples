# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, HttpResponse, redirect

# Create your views here.
def surveys(request):
    return HttpResponse('Placeholder to display all the surveys created.')

def new(request):
    return HttpResponse('Placeholder for users to add a new survey.')

def register(request):
    return HttpResponse("Placeholder for users to create a new user record.")

def login(request):
    return HttpResponse('Placeholder for users to login.')