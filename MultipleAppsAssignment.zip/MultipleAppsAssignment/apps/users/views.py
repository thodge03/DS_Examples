# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, HttpResponse, redirect

# Create your views here.
def users(request):
    return HttpResponse('Placeholder to later display the list of users.')

def register(request):
    return HttpResponse("Placeholder for users to create a new user record.")

def login(request):
    return HttpResponse('Placeholder for users to login.')