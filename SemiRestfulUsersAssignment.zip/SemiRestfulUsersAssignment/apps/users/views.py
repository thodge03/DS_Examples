# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages
from models import User


# Create your views here.
def index(request):
    context = {
        'users': User.objects.all()
    }
    return render(request, 'users/index.html', context)

def new(request):
    return render(request, 'users/new.html')

def create(request):
    errors = User.objects.basic_validator(request.POST)
    if len(errors):
        for tag, error in errors.iteritems():
            messages.error(request, error, extra_tags=tag)
        return redirect('/users/new')
    else:
        User.objects.create(first_name=request.POST['first_name'], last_name=request.POST['last_name'], email=request.POST['email'])
        return redirect('/users')

def show(request, id):
    context = {
        'user': User.objects.get(id=id)
    }
    return render(request, 'users/show.html', context)

def edit(request, id):
    context = {
        'user': User.objects.get(id=id)
    }
    return render(request, 'users/edit.html', context)

def update(request, id):
    errors = User.objects.basic_validator(request.POST)
    if len(errors):
        for tag, error in error.iteritems():
            messages.error(request, error, extra_tags=tag)
        return redirect('/users/' + id + '/edit')
    else:
        user = User.objects.get(id=id)
        user.first_name=request.POST['first_name']
        user.last_name=request.POST['last_name']
        user.email=request.POST['email']
        user.save()
        return redirect('/users/' + id)

def destroy(request, id):
    User.objects.get(id=id).delete()
    return redirect('/users')