# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
import re

# Create your models here.
class UserManager(models.Manager):
    def basic_validator(self, postData):
        errors = {}
        if len(postData['first_name']) < 1:
            errors['first_name'] = 'First name field cannot be left blank.'
        if len(postData['last_name']) < 1:
            errors['last_name'] = 'Last name field cannot be left blank.'
        if len(postData['email']) < 1:
            errors['email'] = 'Email field cannot be left blank.'
        elif not re.compile(r'([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5}$)').match(postData['email']):
            errors['email'] = 'Enter valid email address (something@somesite.com)'
        return errors

class User(models.Model):
    first_name = models.CharField(max_length = 255)
    last_name = models.CharField(max_length = 255)
    email = models.CharField(max_length = 255)
    created_at = models.DateTimeField(auto_now_add=True)
    objects = UserManager()
    def __repr__(self):
        return 'Name: {} {}, Email: {}, Created At: {}'.format(self.first_name, self.last_name, self.email, self.created_at)
