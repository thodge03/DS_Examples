# CD_Django_v2

Coding Dojo Django Assignments- Take 2!
