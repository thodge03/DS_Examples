# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, HttpResponse, redirect

# Create your views here.
def index(request):
    return render(request, 'amadon/index.html')
def process(request):
    if 'item_total' not in request.session.keys():
        request.session['item_total'] = 0
    if 'total_amount' not in request.session.keys():
        request.session['total_amount'] = 0
    
    if request.POST['product_id'] == '1':
        request.session['current_amount'] = 19.99 * int(request.POST['quantity'])
    elif request.POST['product_id'] == '2':
        request.session['current_amount'] = 29.99 * int(request.POST['quantity'])
    elif request.POST['product_id'] == '3':
        request.session['current_amount'] = 4.99 * int(request.POST['quantity'])
    elif request.POST['product_id'] == '4':
        request.session['current_amount'] = 49.99 * int(request.POST['quantity'])
    
    request.session['item_total'] += int(request.POST['quantity'])

    request.session['total_amount'] += request.session['current_amount']

    return redirect('/amadon/result')

def result(request):
    context={
        'current_amount' : request.session['current_amount'],
        'item_total' : request.session['item_total'],
        'total_amount' : request.session['total_amount']
    }
    return render(request, 'amadon/checkout.html', context)

def reset(request):
    for key in request.session.keys():
        del request.session[key]
    return redirect('/amadon')