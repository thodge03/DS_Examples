# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, HttpResponse, redirect
import random
from time import strftime, localtime
# Create your views here.
def index(request):
    if 'total_gold' not in request.session.keys():
        request.session['total_gold'] = 0
    if 'turn_gold' not in request.session.keys():
        request.session['turn_gold'] = 0
    context={
        'total_gold': request.session['total_gold'],
        'turn_gold': request.session['turn_gold']
    }
    return render(request, 'gold/index.html', context)

def process(request):
    if request.POST['building'] == 'farm':
        request.session['turn_gold'] = random.randint(10,20)

    if request.POST['building'] == 'cave':
        request.session['turn_gold'] = random.randint(5,10)

    if request.POST['building'] == 'house':
        request.session['turn_gold'] = random.randint(2,5)

    if request.POST['building'] == 'casino':
        request.session['turn_gold'] = random.randint(-50,50)


    request.session['total_gold'] += request.session['turn_gold']

    return redirect('/')

def reset(request):
    for key in request.session.keys():
        del request.session[key]
    return redirect('/')